# Main script implementing DGWO-based optimized charging in WSN
